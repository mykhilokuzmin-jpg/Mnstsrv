MINI STRIKE V7 — ONLINE MULTIPLAYER STARTER

IMPORTANT: Multiplayer requires a running Node.js server. Netlify alone cannot host this WebSocket server.
This project provides a playable multiplayer foundation, separate from the original V6 solo shooter.

1) Test locally on a computer (Node.js 20+):
   cd server
   npm install
   npm start
   Open public/multiplayer.html using a static server (or deploy the public folder to Netlify).
   Enter ws://localhost:3000 as the multiplayer server address (only for local HTTP testing).

2) Put the server online with Render:
   - Create a new Web Service from a Git repository containing the server directory.
   - Root directory: server
   - Build command: npm install
   - Start command: npm start
   - Deploy and copy the service hostname, e.g. your-mini-strike-server.onrender.com
   - WebSocket address in game: wss://your-mini-strike-server.onrender.com
   - Free hosting plans may sleep or have limitations. Check your provider's current policies.

3) Put game pages online:
   - Upload the CONTENTS of public (or the supplied static_site ZIP) to Netlify.
   - Main Netlify URL opens the existing V6 solo game.
   - Multiplayer at https://YOUR-SITE.netlify.app/multiplayer.html
   - Paste the hosted wss:// server URL and press Connect.
   - Create a room and share the invite link with friends.

This is an experimental multiplayer prototype, NOT a production hardened game service.
Features: 8-player rooms, room codes, co-op waves/bosses, red/blue PvP, map voting, basic
scoreboard, respawns, and touch controls. The solo game's coins, skins, and cases do not yet
synchronize to multiplayer; those remain local to the V6 solo game. No user accounts, anti-cheat,
persistent multiplayer progress, authoritative line-of-sight map collisions, or matchmaking yet.
